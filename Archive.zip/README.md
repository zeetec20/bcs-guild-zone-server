# Guild Zone

## Device
It's device I use to build this project
- Node : 15.14.0

## Run Project
For run this project you must run client side and server side together

### Client Side
```bash
npm install
npm run dev
```

### Serber Side
```bash
npm install
npm run start:dev
```