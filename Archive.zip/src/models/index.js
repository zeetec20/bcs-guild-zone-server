module.exports = {
    Gamer: require('./gamer.model'),
    GuildManager: require('./guildManager.model'),
    Guild: require('./guild.model'),
    Message: require('./message.model'),
    Game: require('./game.model'),
    Member: require('./member.model')
}