module.exports = {
    documentations: require('./documentations.route'),
    user: require('./user.route'),
    guild: require('./guild.route'),
    guildZone: require('./guildZone.route')
}