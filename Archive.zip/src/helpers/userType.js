module.exports = {
    GAMER: 'GAMER',
    GUILD_MANAGER: 'GUILD_MANAGER'
}