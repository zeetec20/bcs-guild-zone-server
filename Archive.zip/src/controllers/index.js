module.exports = {
    user: require('./user.controller'),
    guild: require('./guild.controller'),
    guildZone: require('./guildZone.controller')
}