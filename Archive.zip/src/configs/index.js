module.exports = {
    firebaseConfig: require('./firebaseConfig'),
    env: require('./env'),
    firebase: require('./firebase'),
    firebaseAdmin: require('./firebaseAdmin')
}