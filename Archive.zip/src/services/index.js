module.exports = {
    authentication: require('./authentication.service'),
    guildManager: require('./guildManager.service'),
    guild: require('./guild.service'),
    storage: require('./storage.service'),
    guildZone: require('./guildZone.service'),
    email: require('./email.service')
}